<?php

namespace Api\Controllers;

use Api\API;
use Api\Models\M_api;
use Illuminate\Http\Request;

class C_localidades extends API{


}
