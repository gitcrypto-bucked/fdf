<?php


return [
    'NEWS' => 1, // 1 dia,
    'CHAMADOS'=> 2,
    'DEFAULT' =>1,
    'SYSTEM'=>3
]


?>
