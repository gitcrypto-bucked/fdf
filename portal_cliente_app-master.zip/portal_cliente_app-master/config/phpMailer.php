<?php

return [
    'MAIL'=>[
        'smpt'=>'smtp.office365.com',
        'from'=>'',
        'password'=>'password',
        'port'=>587
    ]
];


?>
