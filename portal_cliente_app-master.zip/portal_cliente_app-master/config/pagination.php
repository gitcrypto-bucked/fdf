<?php


return [
    'NEWS'=>18,
    'CLIENTS'=>22,
    'INVOICES'=>15,
    'INVENTORIES'=>20,
    'DETAILS'=>9,
    'CHAMADOS'=>22,
    'TRACKING' => 12
];

?>
